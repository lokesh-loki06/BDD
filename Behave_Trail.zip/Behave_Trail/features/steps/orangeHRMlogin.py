from behave import *
from selenium import webdriver
from selenium.webdriver.common.by import By


@given('I launch the chrome browser')
def launch_browser(context):
    # context.driver = webdriver.Chrome(executable_path="C:\Drivers\chromedriver_win32\chromedriver.exe")
    context.driver = webdriver.Chrome()
    context.driver.implicitly_wait(10)


@when('I Open Orange HRM home page')
def open_homepage(context):
    context.driver.get("https://opensource-demo.orangehrmlive.com/")


@when('Enter username = "Admin" and password = "admin123"')
def step_impl(context):
    context.driver.find_element(By.XPATH, "//input[@placeholder='Username']").send_keys("Admin")
    context.driver.find_element(By.XPATH, "//input[@placeholder='Password']").send_keys("admin123")


@when('Click on Login button')
def login_button(context):
    context.driver.find_element(By.XPATH, "//button[normalize-space()='Login']").click()


@then('User must successfully enter in to dashboard of orange HRM')
def validate_login_dashboard(context):
    text = context.driver.find_element(By.XPATH, "//h6[normalize-space()='Dashboard']").text
    assert text == "Dashboard"
    context.driver.close()
