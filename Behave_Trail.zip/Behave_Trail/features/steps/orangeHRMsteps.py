from behave import *
from selenium import webdriver
from selenium.webdriver.common.by import By


@given('launch the chrome browser')
def launch_browser(context):
    # context.driver = webdriver.Chrome(executable_path="C:\Drivers\chromedriver_win32\chromedriver.exe")
    context.driver = webdriver.Chrome()
    context.driver.implicitly_wait(10)


@when('Open Orange HRM home page')
def open_homepage(context):
    context.driver.get("https://opensource-demo.orangehrmlive.com/")


@then('Verify the logo present on the page')
def verify_logo(context):
    status = context.driver.find_element(By.XPATH, "//img[@alt='company-branding']").is_displayed()

    assert status is True


@then('close browser')
def close_browser(context):
    context.driver.close()
